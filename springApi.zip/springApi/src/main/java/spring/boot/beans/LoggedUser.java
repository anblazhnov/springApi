package spring.boot.beans;


public interface LoggedUser {
    String addQuiz (Quiz quiz);
    String changeQuiz (Quiz quiz);
    String removeQuiz (String name);
    String listUserQuizzes ();
    String selectQuiz(String name, boolean start);
    String setAnswer(String quizName, String questionText, String answerName, String answerText);
}
