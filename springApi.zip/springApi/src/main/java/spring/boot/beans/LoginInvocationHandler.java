package spring.boot.beans;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.Arrays;

public class LoginInvocationHandler implements InvocationHandler {
    private App app;

    public LoginInvocationHandler(App app) {
        this.app = app;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if (app.getUser() == null) return "need to login first";
        if (
                method.getName().equals("addQuiz") ||
                method.getName().equals("changeQuiz") ||
                method.getName().equals("removeQuiz")
        ) {
            if (app.getUser().getUserType() != User.UserType.ADMIN)
                return "permission denied";
        }
        Arrays.stream(method.getDeclaredAnnotations()).forEach(System.out::println);
        return method.invoke(app, args);
    }
}
